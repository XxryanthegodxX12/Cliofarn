# ClipFarm AI Worker

This Docker worker downloads YouTube sources, obtains a transcript, asks the
ClipFarm API for clip candidates, renders vertical MP4s with captions, and
uploads them to Cloudflare R2.

## Build
Run from the project root:
`docker build -f worker/Dockerfile -t clipfarm-worker .`

## Required environment variables
- `CLIPFARM_API_BASE`
- `CLIPFARM_WORKER_TOKEN`
- `OPENAI_API_KEY`
- `R2_ACCOUNT_ID`
- `R2_ACCESS_KEY_ID`
- `R2_SECRET_ACCESS_KEY`
- `R2_BUCKET`
- `R2_PUBLIC_BASE_URL`

Optional: `POLL_SECONDS=4`, `MAX_CLIPS=5`.

## Before deployment
The backend must implement the worker endpoints used in `worker.py`, including
`POST /api/worker/claim-next`, progress, complete, and fail. The worker has not
been production-validated. Direct uploads are not implemented; use a YouTube URL
until secure upload handoff is configured. Ensure you have rights to process the
source video.
